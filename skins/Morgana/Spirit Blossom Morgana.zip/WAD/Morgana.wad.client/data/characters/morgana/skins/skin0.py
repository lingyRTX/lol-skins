#PROP_text
type: string = "PROP"
version: u32 = 3
linked: list[string] = {
    "DATA/Morgana_Skins_Skin17_Skins_Skin18_Skins_Skin19_Skins_Skin20_Skins_Skin21_Skins_Skin22_Skins_Skin23_Skins_Skin24_Skins_Skin25_Skins_Skin80.bin"
    "DATA/Characters/Morgana/Morgana.bin"
    "DATA/Characters/Morgana/Animations/Skin80.bin"
    "DATA/Characters/Morgana/Skins/Skin80.bin"
    "DATA/Characters/Morgana/gameplay.morganaskin80viewcontroller.bin"
    "ASSETS/Characters/Morgana/Icon.bin"
}
entries: map[hash,embed] = {
    "Characters/Morgana/Skins/Skin0" = SkinCharacterDataProperties {
        SkinClassification: u32 = 1
        ChampionSkinName: string = "MorganaSkin80"
        MetaDataTags: string = "gender:female,faction:demacia,race:angel,element:dark,skinline:spiritblossom,subskinline:akana"
        SkinUpgradeData: embed = SkinUpgradeData {
            SkinAugmentCategories: embed = SkinAugmentCategories {
                BorderAugments: list2[embed] = {
                    0x4a70b12c {
                        0x9a676645: link = 0x6bded2f8
                        AugmentGroup: list2[link] = {
                            0x6bded2f8
                        }
                    }
                }
            }
        }
        Loadscreen: embed = CensoredImage {
            Image: string = "ASSETS/Characters/Morgana/Skins/Skin80/MorganaLoadScreen_80.SKINS_Morgana_Skin80.tex"
        }
        SkinAudioProperties: embed = SkinAudioProperties {
            TagEventList: list[string] = {
                "Morgana"
                "MorganaSkin80"
            }
            BankUnits: list2[embed] = {
                BankUnit {
                    Name: string = "Morgana_Skin80_VO"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Morgana/Skins/Skin80/Morgana_Skin80_VO_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Morgana/Skins/Skin80/Morgana_Skin80_VO_events.bnk"
                        "ASSETS/Sounds/Wwise2016/VO/en_US/Characters/Morgana/Skins/Skin80/Morgana_Skin80_VO_audio.wpk"
                    }
                    Events: list[string] = {
                        "Play_vo_MorganaSkin80_Assist3DAsheSkin76"
                        "Play_vo_MorganaSkin80_Assist3DGeneral"
                        "Play_vo_MorganaSkin80_Assist3DKayleSkin78"
                        "Play_vo_MorganaSkin80_Attack2DBaron"
                        "Play_vo_MorganaSkin80_Attack2DDragon"
                        "Play_vo_MorganaSkin80_Attack2DGeneral"
                        "Play_vo_MorganaSkin80_Death3D"
                        "Play_vo_MorganaSkin80_FirstEncounter3DAhriSkin29"
                        "Play_vo_MorganaSkin80_FirstEncounter3DAkaliSkin92"
                        "Play_vo_MorganaSkin80_FirstEncounter3DAkana"
                        "Play_vo_MorganaSkin80_FirstEncounter3DAsheSkin76"
                        "Play_vo_MorganaSkin80_FirstEncounter3DBardSkin37"
                        "Play_vo_MorganaSkin80_FirstEncounter3DGeneral"
                        "Play_vo_MorganaSkin80_FirstEncounter3DHweiSkin11"
                        "Play_vo_MorganaSkin80_FirstEncounter3DIreliaSkin55"
                        "Play_vo_MorganaSkin80_FirstEncounter3DIvernSkin30"
                        "Play_vo_MorganaSkin80_FirstEncounter3DKanmei"
                        "Play_vo_MorganaSkin80_FirstEncounter3DKarmaSkin70"
                        "Play_vo_MorganaSkin80_FirstEncounter3DKayleSkin78"
                        "Play_vo_MorganaSkin80_FirstEncounter3DLuxSkin70"
                        "Play_vo_MorganaSkin80_FirstEncounter3DNidaleeSkin58"
                        "Play_vo_MorganaSkin80_FirstEncounter3DSettSkin38"
                        "Play_vo_MorganaSkin80_FirstEncounter3DThreshSkin19"
                        "Play_vo_MorganaSkin80_FirstEncounter3DVarusSkin60"
                        "Play_vo_MorganaSkin80_FirstEncounter3DZedSkin69"
                        "Play_vo_MorganaSkin80_FirstEncounter3DZyraSkin64"
                        "Play_vo_MorganaSkin80_Idle3DGeneral"
                        "Play_vo_MorganaSkin80_Joke3DGeneral"
                        "Play_vo_MorganaSkin80_JokeTauntResponse3DGeneral"
                        "Play_vo_MorganaSkin80_Kill3DAhriSkin29"
                        "Play_vo_MorganaSkin80_Kill3DAkana"
                        "Play_vo_MorganaSkin80_Kill3DAsheSkin76"
                        "Play_vo_MorganaSkin80_Kill3DFirst"
                        "Play_vo_MorganaSkin80_Kill3DGeneral"
                        "Play_vo_MorganaSkin80_Kill3DIreliaSkin55"
                        "Play_vo_MorganaSkin80_Kill3DKanmei"
                        "Play_vo_MorganaSkin80_Kill3DKarmaSkin70"
                        "Play_vo_MorganaSkin80_Kill3DKayleSkin78"
                        "Play_vo_MorganaSkin80_Kill3DPenta"
                        "Play_vo_MorganaSkin80_Kill3DSettSkin38"
                        "Play_vo_MorganaSkin80_Kill3DThreshSkin19"
                        "Play_vo_MorganaSkin80_Laugh3DGeneral"
                        "Play_vo_MorganaSkin80_MorganaBasicAttack2_cast3D"
                        "Play_vo_MorganaSkin80_MorganaBasicAttack_cast3D"
                        "Play_vo_MorganaSkin80_MorganaCritAttack_cast3D"
                        "Play_vo_MorganaSkin80_MorganaE_cast3D"
                        "Play_vo_MorganaSkin80_MorganaQ_cast3D"
                        "Play_vo_MorganaSkin80_MorganaR_cast3D"
                        "Play_vo_MorganaSkin80_MorganaW_cast3D"
                        "Play_vo_MorganaSkin80_Move2DFirst"
                        "Play_vo_MorganaSkin80_Move2DFirstAllyAsheSkin76"
                        "Play_vo_MorganaSkin80_Move2DFirstAllyKayleSkin78"
                        "Play_vo_MorganaSkin80_Move2DFirstEnemyKarmaSkin70"
                        "Play_vo_MorganaSkin80_Move2DFirstEnemyKayleSkin78"
                        "Play_vo_MorganaSkin80_Move2DLong"
                        "Play_vo_MorganaSkin80_Move2DStandard"
                        "Play_vo_MorganaSkin80_Recall3DGeneral"
                        "Play_vo_MorganaSkin80_Respawn2DGeneral"
                        "Play_vo_MorganaSkin80_Spell3DEBlockCC"
                        "Play_vo_MorganaSkin80_Spell3DQWCombo_hit3D"
                        "Play_vo_MorganaSkin80_Spell3DRStunHitOne"
                        "Play_vo_MorganaSkin80_Spell3DRStunHitThree"
                        "Play_vo_MorganaSkin80_Spell3DRStunHitTwo"
                        "Play_vo_MorganaSkin80_Taunt3DGeneral"
                        "Play_vo_MorganaSkin80_Unique2DGearNew"
                        "Play_vo_MorganaSkin80_Unique3DGearNew"
                        "Play_vo_MorganaSkin80_UseItem2DWard"
                    }
                    VoiceOver: bool = true
                }
                BankUnit {
                    Name: string = "Morgana_Skin80_SFX"
                    BankPath: list[string] = {
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Morgana/Skins/Skin80/Morgana_Skin80_SFX_audio.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Morgana/Skins/Skin80/Morgana_Skin80_SFX_events.bnk"
                        "ASSETS/Sounds/Wwise2016/SFX/Characters/Morgana/Skins/Skin80/Morgana_Skin80_SFX_audio.wpk"
                    }
                    Events: list[string] = {
                        "mus_skin_morgana_skin80_HUD_mute"
                        "mus_skin_morgana_skin80_HUD_unmute"
                        "mus_skin_morgana_skin80_Q_hit"
                        "mus_skin_morgana_skin80_Q_stun_finish"
                        "mus_skin_morgana_skin80_R_success_1"
                        "mus_skin_morgana_skin80_R_success_2"
                        "mus_skin_morgana_skin80_R_success_3"
                        "mus_skin_morgana_skin80_R_success_4"
                        "mus_skin_morgana_skin80_R_success_5"
                        "mus_skin_morgana_skin80_R_trans_1"
                        "mus_skin_morgana_skin80_R_trans_2"
                        "mus_skin_morgana_skin80_R_trans_3"
                        "mus_skin_morgana_skin80_R_trans_4"
                        "mus_skin_morgana_skin80_R_trans_5"
                        "mus_skin_morgana_skin80_spawn"
                        "Play_sfx_MorganaSkin80_Dance3D_in"
                        "Play_sfx_MorganaSkin80_Dance3D_loop"
                        "Play_sfx_MorganaSkin80_Death3D_cast"
                        "Play_sfx_MorganaSkin80_Deathpetals3D_cast"
                        "Play_sfx_MorganaSkin80_gear_swap"
                        "Play_sfx_MorganaSkin80_Homeguard3D_in"
                        "Play_sfx_MorganaSkin80_Homeguard3D_loop"
                        "Play_sfx_MorganaSkin80_Homeguard3D_steps"
                        "Play_sfx_MorganaSkin80_Homeguard3D_to_idle"
                        "Play_sfx_MorganaSkin80_Homeguard3D_to_run"
                        "Play_sfx_MorganaSkin80_Homeguard3D_to_run_step"
                        "Play_sfx_MorganaSkin80_Idle3D_in1"
                        "Play_sfx_MorganaSkin80_Idle3D_in2"
                        "Play_sfx_MorganaSkin80_Idle3D_spawn"
                        "Play_sfx_MorganaSkin80_Idle3D_variant"
                        "Play_sfx_MorganaSkin80_Joke3D_in"
                        "Play_sfx_MorganaSkin80_Joke3D_var"
                        "Play_sfx_MorganaSkin80_Laugh3D_buffactivate"
                        "Play_sfx_MorganaSkin80_MaskSwap3D_mask1"
                        "Play_sfx_MorganaSkin80_MaskSwap3D_mask2"
                        "Play_sfx_MorganaSkin80_MaskSwap3D_mask3"
                        "Play_sfx_MorganaSkin80_MorganaBasicAttack2_OnCast"
                        "Play_sfx_MorganaSkin80_MorganaBasicAttack2_OnHit"
                        "Play_sfx_MorganaSkin80_MorganaBasicAttack2_OnMissileLaunch"
                        "Play_sfx_MorganaSkin80_MorganaBasicAttack_OnCast"
                        "Play_sfx_MorganaSkin80_MorganaBasicAttack_OnHit"
                        "Play_sfx_MorganaSkin80_MorganaBasicAttack_OnMissileLaunch"
                        "Play_sfx_MorganaSkin80_MorganaCritAttack_OnCast"
                        "Play_sfx_MorganaSkin80_MorganaCritAttack_OnHit"
                        "Play_sfx_MorganaSkin80_MorganaE_butterfly"
                        "Play_sfx_MorganaSkin80_MorganaE_cast_others"
                        "Play_sfx_MorganaSkin80_MorganaE_cast_self"
                        "Play_sfx_MorganaSkin80_MorganaE_OnBuffActivate"
                        "Play_sfx_MorganaSkin80_MorganaE_OnBuffDeactivate"
                        "Play_sfx_MorganaSkin80_MorganaQ_OnBuffActivate"
                        "Play_sfx_MorganaSkin80_MorganaQ_OnCast"
                        "Play_sfx_MorganaSkin80_MorganaQ_OnHit"
                        "Play_sfx_MorganaSkin80_MorganaQ_OnMissileLaunch"
                        "Play_sfx_MorganaSkin80_MorganaR_cast_others"
                        "Play_sfx_MorganaSkin80_MorganaR_cast_self"
                        "Play_sfx_MorganaSkin80_MorganaR_detonate"
                        "Play_sfx_MorganaSkin80_MorganaR_hit_others"
                        "Play_sfx_MorganaSkin80_MorganaR_hit_self"
                        "Play_sfx_MorganaSkin80_MorganaR_OnBuffDeactivate"
                        "Play_sfx_MorganaSkin80_MorganaR_stuncount_01"
                        "Play_sfx_MorganaSkin80_MorganaR_stuncount_02"
                        "Play_sfx_MorganaSkin80_MorganaR_stuncount_03"
                        "Play_sfx_MorganaSkin80_MorganaR_stuncount_04"
                        "Play_sfx_MorganaSkin80_MorganaR_stuncount_05"
                        "Play_sfx_MorganaSkin80_MorganaW1_butterfly"
                        "Play_sfx_MorganaSkin80_MorganaW1_cast"
                        "Play_sfx_MorganaSkin80_MorganaW2_butterfly"
                        "Play_sfx_MorganaSkin80_MorganaW2_cast"
                        "Play_sfx_MorganaSkin80_Petals3D_loop"
                        "Play_sfx_MorganaSkin80_Recall3D_generic_out"
                        "Play_sfx_MorganaSkin80_Recall3D_mask1_in"
                        "Play_sfx_MorganaSkin80_Recall3D_mask2_in"
                        "Play_sfx_MorganaSkin80_Recall3D_mask3_in"
                        "Play_sfx_MorganaSkin80_Recall3D_winddown"
                        "Play_sfx_MorganaSkin80_Taunt3D_leadin"
                        "Play_sfx_MorganaSkin80_Taunt3D_spam"
                        "Stop_sfx_MorganaSkin80_Dance3D_in"
                        "Stop_sfx_MorganaSkin80_Homeguard3D_in"
                        "Stop_sfx_MorganaSkin80_Homeguard3D_loop"
                        "Stop_sfx_MorganaSkin80_Homeguard3D_to_idle"
                        "Stop_sfx_MorganaSkin80_Homeguard3D_to_run"
                        "Stop_sfx_MorganaSkin80_Idle3D_in1"
                        "Stop_sfx_MorganaSkin80_Idle3D_in2"
                        "Stop_sfx_MorganaSkin80_Idle3D_spawn"
                        "Stop_sfx_MorganaSkin80_Idle3D_variant"
                        "Stop_sfx_MorganaSkin80_Joke3D_loop"
                        "Stop_sfx_MorganaSkin80_MaskSwap3D_mask1"
                        "Stop_sfx_MorganaSkin80_MaskSwap3D_mask2"
                        "Stop_sfx_MorganaSkin80_MaskSwap3D_mask3"
                        "Stop_sfx_MorganaSkin80_MorganaBasicAttack2_OnMissileLaunch"
                        "Stop_sfx_MorganaSkin80_MorganaBasicAttack_OnMissileLaunch"
                        "Stop_sfx_MorganaSkin80_MorganaE_butterfly"
                        "Stop_sfx_MorganaSkin80_MorganaE_OnBuffActivate"
                        "Stop_sfx_MorganaSkin80_MorganaQ_OnBuffActivate"
                        "Stop_sfx_MorganaSkin80_MorganaQ_OnHit"
                        "Stop_sfx_MorganaSkin80_MorganaQ_OnMissileLaunch"
                        "Stop_sfx_MorganaSkin80_MorganaW1_butterfly"
                        "Stop_sfx_MorganaSkin80_MorganaW1_cast"
                        "Stop_sfx_MorganaSkin80_MorganaW2_butterfly"
                        "Stop_sfx_MorganaSkin80_MorganaW2_cast"
                        "Stop_sfx_MorganaSkin80_Petals3D_loop"
                        "Stop_sfx_MorganaSkin80_Recall3D_generic_out"
                        "Stop_sfx_MorganaSkin80_Recall3D_mask1_in"
                        "Stop_sfx_MorganaSkin80_Recall3D_mask2_in"
                        "Stop_sfx_MorganaSkin80_Recall3D_mask3_in"
                        "Stop_sfx_MorganaSkin80_Recall3D_winddown"
                    }
                }
            }
        }
        SkinAnimationProperties: embed = SkinAnimationProperties {
            AnimationGraphData: link = 0xd693941f
        }
        SkinMeshProperties: embed = SkinMeshDataProperties {
            Skeleton: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80.SKINS_Morgana_Skin80.skl"
            SimpleSkin: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80.SKINS_Morgana_Skin80.skn"
            Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_TX_CM.SKINS_Morgana_Skin80.tex"
            SkinScale: f32 = 1.32000005
            SelfIllumination: f32 = 0.699999988
            OverrideBoundingBox: option[vec3] = {
                { 100, 145, 100 }
            }
            Material: link = 0xa9f40391
            ReflectionFresnelColor: rgba = { 0, 0, 0, 255 }
            InitialSubmeshToHide: string = "BodyMask_02 BodyMask_03 FX_Wings Horns Mask_01 Mask_02 Mask_03 SecondFormWing SecondFormWingShoulder Superbloom SuperbloomUlt"
            SubmeshRenderOrder: string = "Body Superbloom Horns FirstForm WingShoulders SecondFormWingShoulder Rope BodyMask_01 BodyMask_02 BodyMask_03 Flower Wings SecondFormWing Mask_01 Mask_02 Mask_03 FX_Wings"
            MaterialOverride: list[embed] = {
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
                    Submesh: string = "Mask_01"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
                    Submesh: string = "Mask_02"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
                    Submesh: string = "Mask_03"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x773fb763
                    Submesh: string = "Wings"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x773fb763
                    Submesh: string = "WingShoulders"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Horn_Mask_TX_CM.SKINS_Morgana_Skin80.tex"
                    Submesh: string = "Horns"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0xa9f40391
                    Submesh: string = "Superbloom"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
                    Submesh: string = "BodyMask_01"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
                    Submesh: string = "BodyMask_02"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
                    Submesh: string = "BodyMask_03"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x773fb763
                    Submesh: string = "Flower"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0x773fb763
                    Submesh: string = "SecondFormWing"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_ShoulderWings_TX_CM.SKINS_Morgana_Skin80.tex"
                    Submesh: string = "SecondFormWingShoulder"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Material: link = 0xa9f40391
                    Submesh: string = "SuperbloomUlt"
                }
                SkinMeshDataProperties_MaterialOverride {
                    Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Evolve_TX_CM.SKINS_Morgana_Skin80.tex"
                    Submesh: string = "Rope"
                }
            }
            RigPoseModifierData: list[pointer] = {
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xfaf0233c
                    mEndingJointName: hash = 0x562fb374
                    mDefaultMaskName: hash = "Default"
                    mMaxBoneAngle: f32 = 30
                    mDampingValue: f32 = 1
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xbb5e8784
                    mEndingJointName: hash = 0xbd5e8aaa
                    mDefaultMaskName: hash = "Default"
                    mMaxBoneAngle: f32 = 24
                    mDampingValue: f32 = 2
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x7054dee2
                    mEndingJointName: hash = 0x6e54dbbc
                    mDefaultMaskName: hash = "Default"
                    mMaxBoneAngle: f32 = 24
                    mDampingValue: f32 = 2
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x2b56e90f
                    mEndingJointName: hash = 0x2d56ec35
                    mDefaultMaskName: hash = "Default"
                    mMaxBoneAngle: f32 = 24
                    mDampingValue: f32 = 2
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x78572a11
                    mEndingJointName: hash = 0x765726eb
                    mDefaultMaskName: hash = "Default"
                    mMaxBoneAngle: f32 = 24
                    mDampingValue: f32 = 2
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x2f592df2
                    mEndingJointName: hash = 0x2d592acc
                    mDefaultMaskName: hash = "Default"
                    mMaxBoneAngle: f32 = 24
                    mDampingValue: f32 = 2
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xfc5a3874
                    mEndingJointName: hash = 0xfe5a3b9a
                    mDefaultMaskName: hash = "Default"
                    mMaxBoneAngle: f32 = 24
                    mDampingValue: f32 = 2
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xbf51c1dd
                    mEndingJointName: hash = 0xbd51beb7
                    mDefaultMaskName: hash = "Default"
                    mMaxBoneAngle: f32 = 24
                    mDampingValue: f32 = 2
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xf448e2bb
                    mEndingJointName: hash = 0xf648e5e1
                    mDefaultMaskName: hash = "Default"
                    mMaxBoneAngle: f32 = 24
                    mDampingValue: f32 = 2
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x69f61932
                    mEndingJointName: hash = 0x1733d847
                    mDefaultMaskName: hash = 0xa2c0a94a
                    mMaxBoneAngle: f32 = 25
                    mDampingValue: f32 = 1
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xd7495612
                    mEndingJointName: hash = 0x7f85b76a
                    mDefaultMaskName: hash = 0xa2c0a94a
                    mMaxBoneAngle: f32 = 25
                    mDampingValue: f32 = 1
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0x8f0f7600
                    mEndingJointName: hash = 0xe890a27d
                    mDefaultMaskName: hash = 0xa2c0a94a
                    mMaxBoneAngle: f32 = 25
                    mDampingValue: f32 = 1
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xc19794ac
                    mEndingJointName: hash = 0xa297654c
                    mDefaultMaskName: hash = 0xa2c0a94a
                    mMaxBoneAngle: f32 = 25
                    mDampingValue: f32 = 1
                }
                ConformToPathRigPoseModifierData {
                    mStartingJointName: hash = 0xd27e06ac
                    mEndingJointName: hash = 0x234934b9
                    mDefaultMaskName: hash = "Default"
                }
            }
        }
        ArmorMaterial: string = "Flesh"
        ThemeMusic: list[string] = {
            "mus_skin_morgana_skin80_spawn"
            "mus_skin_morgana_skin80_R_trans_1"
            "mus_skin_morgana_skin80_R_trans_2"
            "mus_skin_morgana_skin80_R_trans_3"
            "mus_skin_morgana_skin80_R_trans_4"
            "mus_skin_morgana_skin80_R_trans_5"
            "mus_skin_morgana_skin80_R_success_1"
            "mus_skin_morgana_skin80_R_success_2"
            "mus_skin_morgana_skin80_R_success_3"
            "mus_skin_morgana_skin80_R_success_4"
            "mus_skin_morgana_skin80_R_success_5"
            "mus_skin_morgana_skin80_Q_hit"
            "mus_skin_morgana_skin80_Q_stun_finish"
        }
        CanShareThemeMusic: bool = false
        HudMuteEvent: string = "mus_skin_morgana_skin80_HUD_mute"
        HudUnmuteEvent: string = "mus_skin_morgana_skin80_HUD_unmute"
        0x2ac577e2: bool = true
        DefaultAnimations: list[string] = {
            "Mouth"
        }
        mContextualActionData: link = 0x9705a35d
        IconCircle: option[string] = {
            "ASSETS/Characters/Morgana/HUD/Morgana_Circle_0.tex"
        }
        IconSquare: option[string] = {
            "ASSETS/Characters/Morgana/HUD/Morgana_Square.tex"
        }
        IconAvatar: string = "ASSETS/Characters/Morgana/Icon/null.tex"
        HealthBarData: embed = CharacterHealthBarDataRecord {
            AttachToBone: string = "Buffbone_Cstm_Healthbar"
            UnitHealthBarStyle: u8 = 12
        }
        mEmblems: list[embed] = {
            SkinEmblem {
                mEmblemData: link = 0x36adfd9d
            }
        }
        mResourceResolver: link = "Characters/Morgana/Skins/Skin0/Resources"
        PersistentEffectConditions: list2[pointer] = {
            PersistentEffectConditionData {
                OwnerCondition: pointer = HasBuffDynamicMaterialBoolDriver {
                    Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "C_Buffbone_Glb_Layout_Loc"
                        EffectKey: hash = 0x7a8238a8
                    }
                    PersistentVfxData {
                        BoneName: string = "Root"
                        EffectKey: hash = 0xcd16d437
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = NotMaterialDriver {
                    mDriver: pointer = 0xfe70e9c4 {
                        0x3ef62dce: u8 = 5
                        0x4e748038: u8 = 2
                    }
                }
                SourceCondition: pointer = IsAnimationPlayingDynamicMaterialBoolDriver {
                    mAnimationNames: list[hash] = {
                        "Idle1"
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Glb_Ground_Loc"
                        EffectKey: hash = 0x5a85e539
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = AllTrueMaterialDriver {
                    mDrivers: list[pointer] = {
                        HasBuffDynamicMaterialBoolDriver {
                            Spell: hash = 0x2b6e7332
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Wisteria_D3"
                        EffectKey: hash = 0x106d7659
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Wisteria_D3"
                        EffectKey: hash = 0x106d7659
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Wisteria_A3"
                        EffectKey: hash = 0x106d7659
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Wisteria_A3"
                        EffectKey: hash = 0x106d7659
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Finger1_2"
                        EffectKey: hash = 0x2f21e827
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Finger1_2"
                        EffectKey: hash = 0x2f21e827
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = NotMaterialDriver {
                    mDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                        Spell: hash = 0x2b6e7332
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Wisteria_D3"
                        EffectKey: hash = 0x97336bd4
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Wisteria_D3"
                        EffectKey: hash = 0x97336bd4
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Wisteria_A3"
                        EffectKey: hash = 0x97336bd4
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Wisteria_A3"
                        EffectKey: hash = 0x97336bd4
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Finger1_2"
                        EffectKey: hash = 0x2f21e827
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Finger1_2"
                        EffectKey: hash = 0x2f21e827
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = AllTrueMaterialDriver {
                    mDrivers: list[pointer] = {
                        HasBuffWithAttributeBoolDriver {}
                        OneTrueMaterialDriver {
                            mDrivers: list[pointer] = {
                                HasGearDynamicMaterialBoolDriver {}
                                HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 1
                                }
                                HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 2
                                }
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Spine1"
                        EffectKey: hash = 0x33d83abb
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = AllTrueMaterialDriver {
                    mDrivers: list[pointer] = {
                        HasBuffWithAttributeBoolDriver {}
                        OneTrueMaterialDriver {
                            mDrivers: list[pointer] = {
                                HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 3
                                }
                                HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 4
                                }
                                HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 5
                                }
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Spine1"
                        EffectKey: hash = 0x8f88b97a
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = AllTrueMaterialDriver {
                    mDrivers: list[pointer] = {
                        IsMovingBoolDriver {}
                        HasBuffWithAttributeBoolDriver {}
                        OneTrueMaterialDriver {
                            mDrivers: list[pointer] = {
                                HasGearDynamicMaterialBoolDriver {}
                                HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 1
                                }
                                HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 2
                                }
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Glb_Ground_Loc"
                        EffectKey: hash = 0x04788e64
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = AllTrueMaterialDriver {
                    mDrivers: list[pointer] = {
                        IsMovingBoolDriver {}
                        HasBuffWithAttributeBoolDriver {}
                        OneTrueMaterialDriver {
                            mDrivers: list[pointer] = {
                                HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 3
                                }
                                HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 4
                                }
                                HasGearDynamicMaterialBoolDriver {
                                    mGearIndex: u8 = 5
                                }
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Glb_Ground_Loc"
                        EffectKey: hash = 0x7b9f8e23
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = OneTrueMaterialDriver {
                    mDrivers: list[pointer] = {
                        0xfe70e9c4 {
                            0x3ef62dce: u8 = 3
                        }
                        DelayedBoolMaterialDriver {
                            mBoolDriver: pointer = IsMovingBoolDriver {}
                            mDelayOn: f32 = 3
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Cstm_Buffbone_VFX_Butterfly"
                        EffectKey: hash = 0x24d3862d
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = AllTrueMaterialDriver {
                    mDrivers: list[pointer] = {
                        HasBuffDynamicMaterialBoolDriver {
                            Spell: hash = 0x2b6e7332
                        }
                        NotMaterialDriver {
                            mDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                                mScriptName: string = "Morganarhaste"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Up_Elbow"
                        EffectKey: hash = 0x7ee608dc
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Up_Elbow"
                        EffectKey: hash = 0x721fa9ea
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = AllTrueMaterialDriver {
                    mDrivers: list[pointer] = {
                        SubmeshVisibilityBoolDriver {
                            Submeshes: list[hash] = {
                                0x3db27795
                            }
                            Visible: bool = true
                        }
                        IsAnimationPlayingDynamicMaterialBoolDriver {
                            mAnimationNames: list[hash] = {
                                "Run"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Cstm_Buffbone_VFX_Butterfly"
                        EffectKey: hash = 0x8b226ad3
                    }
                    PersistentVfxData {
                        BoneName: string = "Cstm_Buffbone_VFX_Butterfly"
                        EffectKey: hash = 0x7752c1e0
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = AllTrueMaterialDriver {
                    mDrivers: list[pointer] = {
                        SubmeshVisibilityBoolDriver {
                            Submeshes: list[hash] = {
                                0x3ab272dc
                            }
                            Visible: bool = true
                        }
                        IsAnimationPlayingDynamicMaterialBoolDriver {
                            mAnimationNames: list[hash] = {
                                "Run"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Cstm_Buffbone_VFX_Butterfly"
                        EffectKey: hash = 0x8c226c66
                    }
                    PersistentVfxData {
                        BoneName: string = "Cstm_Buffbone_VFX_Butterfly"
                        EffectKey: hash = 0x7a52c699
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = AllTrueMaterialDriver {
                    mDrivers: list[pointer] = {
                        SubmeshVisibilityBoolDriver {
                            Submeshes: list[hash] = {
                                0x3bb2746f
                            }
                            Visible: bool = true
                        }
                        IsAnimationPlayingDynamicMaterialBoolDriver {
                            mAnimationNames: list[hash] = {
                                "Run"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Cstm_Buffbone_VFX_Butterfly"
                        EffectKey: hash = 0x8d226df9
                    }
                    PersistentVfxData {
                        BoneName: string = "Cstm_Buffbone_VFX_Butterfly"
                        EffectKey: hash = 0x7952c506
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = SubmeshVisibilityBoolDriver {
                    Submeshes: list[hash] = {
                        0xd418986e
                    }
                    Visible: bool = true
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Glb_Ground_Loc"
                        EffectKey: hash = 0xb32b648d
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Up_Finger3"
                        EffectKey: hash = 0xb7cb465d
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Up_Finger3"
                        EffectKey: hash = 0x208dcd2f
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = FixedDurationTriggeredBoolDriver {
                        mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                            Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                        }
                        mCustomDuration: f32 = 86400
                    }
                    mDelayOn: f32 = 360
                }
                SubmeshesToShow: list2[hash] = {
                    0xa541fe49
                    0x3ae80610
                    0xf17b9bf8
                    0xc1f6e907
                    0xd418986e
                }
                SubmeshesToHide: list2[hash] = {
                    0xf8a623eb
                    0x23ccd522
                    0x18fa64cb
                    0x13bc8837
                    0x4044a22d
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = FixedDurationTriggeredBoolDriver {
                        mBoolDriver: pointer = HasBuffDynamicMaterialBoolDriver {
                            Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                        }
                        mCustomDuration: f32 = 86400
                    }
                    mDelayOn: f32 = 359
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        EffectKey: hash = 0xd4c5746c
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = SubmeshVisibilityBoolDriver {
                    Submeshes: list[hash] = {
                        0xf17b9bf8
                    }
                    Visible: bool = true
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Glb_Ground_Loc"
                        EffectKey: hash = 0xb32b648d
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Up_Finger3"
                        EffectKey: hash = 0xb7cb465d
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Up_Finger3"
                        EffectKey: hash = 0x208dcd2f
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Up_Elbow"
                        EffectKey: hash = 0x44d03712
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Up_Elbow"
                        EffectKey: hash = 0x480da39c
                    }
                    PersistentVfxData {
                        EffectKey: hash = 0x179a455d
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Wisteria_A3"
                        EffectKey: hash = 0x55cda515
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Wisteria_C3"
                        EffectKey: hash = 0x55cda515
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Wisteria_A3"
                        EffectKey: hash = 0x55cda515
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Wisteria_C3"
                        EffectKey: hash = 0x55cda515
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xa541fe49
                                }
                                Visible: bool = true
                            }
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x3db27795
                                }
                                Visible: bool = true
                            }
                            HasBuffDynamicMaterialBoolDriver {
                                Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Cstm_Healthbar"
                        EffectKey: hash = 0x20b8a4b5
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xa541fe49
                                }
                                Visible: bool = true
                            }
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x3ab272dc
                                }
                                Visible: bool = true
                            }
                            HasBuffDynamicMaterialBoolDriver {
                                Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Cstm_Healthbar"
                        EffectKey: hash = 0x998d1410
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xa541fe49
                                }
                                Visible: bool = true
                            }
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x3bb2746f
                                }
                                Visible: bool = true
                            }
                            HasBuffDynamicMaterialBoolDriver {
                                Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Cstm_Healthbar"
                        EffectKey: hash = 0x5b105913
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xa541fe49
                                }
                                Visible: bool = true
                            }
                            HasBuffDynamicMaterialBoolDriver {
                                Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Cstm_Healthbar"
                        EffectKey: hash = 0x6a8a8f8a
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xa541fe49
                                }
                                Visible: bool = true
                            }
                            IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Idle1"
                                }
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "BUFFBONE_GLB_GROUND_LOC"
                        EffectKey: hash = 0xbab4b8ea
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xa541fe49
                                }
                                Visible: bool = true
                            }
                            IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Taunt"
                                }
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Hand"
                        EffectKey: hash = 0xb2c2cfe8
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Hand"
                        EffectKey: hash = 0xbce4cf06
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "spine1"
                        EffectKey: hash = 0xecd6b378
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xa541fe49
                                }
                                Visible: bool = true
                            }
                            IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Run_Homeguard"
                                }
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "BUFFBONE_GLB_GROUND_LOC"
                        EffectKey: hash = 0xf8b6848c
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = FixedDurationTriggeredBoolDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xa541fe49
                                }
                                Visible: bool = true
                            }
                            IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Death"
                                }
                            }
                        }
                    }
                    mCustomDuration: f32 = 10
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "BUFFBONE_GLB_GROUND_LOC"
                        EffectKey: hash = 0x6736ad73
                    }
                    PersistentVfxData {
                        BoneName: string = "BUFFBONE_GLB_GROUND_LOC"
                        EffectKey: hash = 0x90b7b10b
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = SubmeshVisibilityBoolDriver {
                    Submeshes: list[hash] = {
                        0x13bc8837
                    }
                    Visible: bool = true
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Glb_Ground_Loc"
                        EffectKey: hash = 0xf5e18ccf
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Up_Elbow"
                        EffectKey: hash = 0x7d0e1f46
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Up_Elbow"
                        EffectKey: hash = 0x9910a71c
                    }
                    PersistentVfxData {
                        EffectKey: hash = 0x6829bd5f
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Wisteria_A3"
                        EffectKey: hash = 0xf8a9ba57
                    }
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Wisteria_C3"
                        EffectKey: hash = 0xf8a9ba57
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Wisteria_A3"
                        EffectKey: hash = 0xf8a9ba57
                    }
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Wisteria_C3"
                        EffectKey: hash = 0xf8a9ba57
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x4044a22d
                                }
                                Visible: bool = true
                            }
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x3db27795
                                }
                                Visible: bool = true
                            }
                            HasBuffDynamicMaterialBoolDriver {
                                Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Cstm_Healthbar"
                        EffectKey: hash = 0xe460dc77
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x4044a22d
                                }
                                Visible: bool = true
                            }
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x3ab272dc
                                }
                                Visible: bool = true
                            }
                            HasBuffDynamicMaterialBoolDriver {
                                Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Cstm_Healthbar"
                        EffectKey: hash = 0x35d052e8
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x4044a22d
                                }
                                Visible: bool = true
                            }
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x3bb2746f
                                }
                                Visible: bool = true
                            }
                            HasBuffDynamicMaterialBoolDriver {
                                Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Cstm_Healthbar"
                        EffectKey: hash = 0x5ea8eed9
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x4044a22d
                                }
                                Visible: bool = true
                            }
                            HasBuffDynamicMaterialBoolDriver {
                                Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "Buffbone_Cstm_Healthbar"
                        EffectKey: hash = 0x59dd483e
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x4044a22d
                                }
                                Visible: bool = true
                            }
                            IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Taunt"
                                }
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "R_Wing_Mid_Hand"
                        EffectKey: hash = 0x2d3bbd40
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "L_Wing_Mid_Hand"
                        EffectKey: hash = 0x5dcdb9c2
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "spine1"
                        EffectKey: hash = 0x58a19010
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x4044a22d
                                }
                                Visible: bool = true
                            }
                            IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Run_Homeguard"
                                }
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "BUFFBONE_GLB_GROUND_LOC"
                        EffectKey: hash = 0x04788e64
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = DelayedBoolMaterialDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x4044a22d
                                }
                                Visible: bool = true
                            }
                            IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Idle1"
                                }
                            }
                        }
                    }
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "BUFFBONE_GLB_GROUND_LOC"
                        EffectKey: hash = 0x4589841e
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = FixedDurationTriggeredBoolDriver {
                    mBoolDriver: pointer = AllTrueMaterialDriver {
                        mDrivers: list[pointer] = {
                            SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0x4044a22d
                                }
                                Visible: bool = true
                            }
                            IsAnimationPlayingDynamicMaterialBoolDriver {
                                mAnimationNames: list[hash] = {
                                    "Death"
                                }
                            }
                        }
                    }
                    mCustomDuration: f32 = 10
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        BoneName: string = "BUFFBONE_GLB_GROUND_LOC"
                        EffectKey: hash = 0x1efe93b9
                    }
                    PersistentVfxData {
                        BoneName: string = "BUFFBONE_GLB_GROUND_LOC"
                        EffectKey: hash = 0x5809f1b1
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = SubmeshVisibilityBoolDriver {
                    Submeshes: list[hash] = {
                        0x3db27795
                    }
                    Visible: bool = true
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        AttachToCamera: bool = true
                        Scale: f32 = 0.100000001
                        EffectKey: hash = 0x3dced93f
                    }
                    PersistentVfxData {
                        AttachToCamera: bool = true
                        EffectKey: hash = 0xb46dc93d
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = SubmeshVisibilityBoolDriver {
                    Submeshes: list[hash] = {
                        0x3ab272dc
                    }
                    Visible: bool = true
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        AttachToCamera: bool = true
                        Scale: f32 = 0.100000001
                        EffectKey: hash = 0x3ecedad2
                    }
                    PersistentVfxData {
                        AttachToCamera: bool = true
                        EffectKey: hash = 0xb16dc484
                    }
                }
            }
            PersistentEffectConditionData {
                OwnerCondition: pointer = SubmeshVisibilityBoolDriver {
                    Submeshes: list[hash] = {
                        0x3bb2746f
                    }
                    Visible: bool = true
                }
                PersistentVfxs: list2[embed] = {
                    PersistentVfxData {
                        AttachToCamera: bool = true
                        Scale: f32 = 0.100000001
                        EffectKey: hash = 0x3fcedc65
                    }
                    PersistentVfxData {
                        AttachToCamera: bool = true
                        EffectKey: hash = 0xb26dc617
                    }
                }
            }
        }
    }
    "Characters/Morgana/Skins/Skin0/Resources" = ResourceResolver {
        ResourceMap: map[hash,link] = {
            0xd4c5746c = 0xac37d63a
            0xf5e18ccf = 0xd401cb61
            0x7d0e1f46 = 0x1582189d
            0x9910a71c = 0xcacd403d
            0x6829bd5f = 0x706ce941
            0xf8a9ba57 = 0x127f0462
            0xb32b648d = 0xa813fe78
            0xb7cb465d = 0x12889945
            0x208dcd2f = 0x54596e0f
            0x44d03712 = 0xbf78a6ff
            0x480da39c = 0x3acf289f
            0x179a455d = 0x8acd7d03
            0x55cda515 = 0x60cbefac
            "Morgana_BA_Cas" = 0x301fb40d
            0x811c9dc5 = 0xf93aa6cf
            "Morgana_BA__one_Mis" = 0xf5a90481
            "Morgana_BA_Mis" = 0xf5a90481
            "Morgana_BA_Tar" = 0xfbfa3305
            0x211ed761 = 0xda298087
            0x28cea986 = 0xb5059a8e
            0x27cea7f3 = 0x3d88210f
            0x203a43f2 = 0x1a9f128e
            0x1f3a425f = 0x67fffb06
            0x1e3a40cc = 0xc6b4aca9
            0x811c9dc5 = 0xefb1ed8d
            0x811c9dc5 = 0x036a71a9
            "Morgana_Q_Mis" = 0x42576585
            "Morgana_Q_mis_resolve" = 0xb0542e70
            0x1b986e5a = 0xbb410026
            0x1a986cc7 = 0x64517ea0
            0x19986b34 = 0x65518033
            0x811c9dc5 = 0x24b2e0a9
            0x811c9dc5 = 0xcf3aa5a4
            "Morgana_Q_Tar" = 0xd70e6f29
            "Morgana_Q_Tar_Buf" = 0x7a1b240b
            0xfd8fb60e = 0xe718f36b
            0xfc8fb47b = 0x600722a9
            0xfb8fb2e8 = 0x01527106
            0x811c9dc5 = 0xd7b0d478
            0x811c9dc5 = 0xed467ffb
            0x811c9dc5 = 0x98c6e464
            "Morgana_Q_Cas" = 0x00000000
            "Morgana_Q_Cas_Trail" = 0x00000000
            0xee87807a = 0x0d73036f
            0x6147b630 = 0x92542cd5
            0x370ff0ef = 0x4487837e
            0x811c9dc5 = 0xb2a6ad6d
            0x811c9dc5 = 0x725c1073
            0x811c9dc5 = 0xdc23588f
            0x811c9dc5 = 0x39441d30
            0x811c9dc5 = 0xabbe2c58
            0x811c9dc5 = 0x502fddb2
            0x811c9dc5 = 0xe7c3f645
            0x811c9dc5 = 0x130f5c44
            0x811c9dc5 = 0xed8dd272
            "Morgana_W_buf" = 0xccd325e5
            "Morgana_W_Tar_Green" = 0xe03c7e63
            "Morgana_W_Tar_Red" = 0xc9cd7966
            "Morgana_W_Cas" = 0x79d4b01d
            0x8cc5b26a = 0xab3f0e3f
            0xc4c94d10 = 0xa609b395
            0x8e24f8ad = 0x8c2b6afa
            0x97b1208c = 0x581073e4
            0x9fd644fc = 0xabbdbba7
            0x38f01fac = 0x0f67f3c9
            0x8e5969f9 = 0x855bbec8
            0x811c9dc5 = 0x8fc8b0c8
            0x811c9dc5 = 0x3f4a9234
            0x811c9dc5 = 0xb6bad902
            "Morgana_E_Cas" = 0xfd9fe69e
            0xd91dcdb1 = 0xbc0fb533
            "Morgana_E_Tar" = 0x0ba7d398
            0x58ed2e8c = 0x5832c379
            0x1883e419 = 0x6cf35ccf
            0x811c9dc5 = 0x2a1f3992
            "Morgana_P_Heal" = 0xd7f4185f
            "Morgana_P_Enrage_Buff" = 0x6dccc108
            "Morgana_R_Buff" = 0xb260dbb2
            0x59dd483e = 0xd70fad14
            "Morgana_R_cas" = 0xaa085c6b
            0xe460dc77 = 0xe83e4e99
            0x35d052e8 = 0xe53e49e0
            0x5ea8eed9 = 0xa3f51e36
            0xbcc202c8 = 0x11bf1270
            0x3e939e5f = 0xe9a81509
            0x5493c101 = 0x5c02f0a8
            0xe282050b = 0x7b379c94
            0x6a8a8f8a = 0x5a4c78ff
            0x4de9b6c3 = 0x3bc6b5aa
            0x20b8a4b5 = 0xa6f522ef
            0x998d1410 = 0xa5f5215c
            0x5b105913 = 0xa8f52615
            0x6f251162 = 0x28e6db93
            0x811c9dc5 = 0x5d2de9ef
            0x811c9dc5 = 0xbbbb8a8b
            0x811c9dc5 = 0x85e4e4ce
            "Morgana_R_Tar_Explode" = 0x11821d14
            "Morgana_R_Beam" = 0x297eeea9
            "Morgana_R_Beam_Break" = 0x43350acd
            "Morgana_R_beam_break_tar" = 0x1f47681a
            "Morgana_R_Initial_Mis" = 0x58d5d18f
            "Morgana_R_Ground_shadow_tar" = 0x934f2e44
            "Morgana_R_Beam_UnderGlow" = 0x24b86690
            0x0aa2c4da = 0xf34a2710
            0x273ebdf1 = 0x52c61d91
            0x0ae3761c = 0x194b95e2
            0xa3445756 = 0x76d751df
            0xa3f69853 = 0x273d41b0
            0x5a70d334 = 0x1934fded
            0x5781fbdd = 0x8bff0e38
            0xaf234aaa = 0xfa3b2163
            0x933b430c = 0xc8cb909d
            0x45717e36 = 0x5b0fc981
            0xcd16d437 = 0xa54f4e2a
            0x7a8238a8 = 0x245f4a84
            0x0ab14767 = 0x8e8e8754
            0x97e887b1 = 0xe53e49e0
            0x8abdfcea = 0x297eeea9
            0x34d8b095 = 0x86ecfcbe
            0xa23ec6f2 = 0x49c50475
            0x96c7a2f6 = 0x4180e7d9
            0xe044d5cc = 0x117c1f1b
            0x2e147322 = 0x36b53251
            0xda3186f0 = 0x66b100b3
            0x151d089b = 0xa83e382c
            0x25b506cb = 0xef40e688
            0x1a1d107a = 0xa73e3699
            0x23c03c98 = 0xf1341dbb
            0xb756159b = 0x578931b0
            0x247d1fc0 = 0x6a3a6bf7
            0xb40a2714 = 0x808b0aa7
            0xd1fc0592 = 0xb08fd365
            0x052004e5 = 0x1bb95276
            0xfe1ff9e0 = 0x1eb9572f
            0xa86739b5 = 0xf4c3a26d
            0xfc90f6bd = 0xc4c3745b
            "Morgana_Emote_Recall_FlowerFlourish" = 0x00000000
            "Morgana_Emote_Recall" = 0x00000000
            0xb6b460f1 = 0xa3a11de9
            0x349e3a14 = 0x52aa3410
            0x359e3ba7 = 0x53aa35a3
            0xf0b58a7e = 0xf5a422e6
            0x1463bb2e = 0x29f8b5d6
            0x0ca63081 = 0x6c97a2db
            0x0ba62eee = 0x6b97a148
            0xe75c1f83 = 0xf06bcf7a
            0x43f5b31f = 0xbc24d608
            0xb92aa7e8 = 0x38b665f0
            0x5ff85a69 = 0xe32ac2b1
            0x4f8dd0a1 = 0xc3afe76a
            0xc8be0212 = 0xa1c35c3a
            0xd38c51b0 = 0xdfe64141
            0xd96ab277 = 0xa2a5592c
            0xdf132cf7 = 0x095fda4f
            0x7be7203c = 0x1c24c9d4
            0x87f1e703 = 0x5a29502b
            0xb09d8e8b = 0x463d56f3
            0x78b5a0bc = 0x301aab94
            0x21375c5c = 0x75113564
            0x142086fb = 0xc7829503
            0xe20a7e9a = 0x6e8100d2
            0xb7c28255 = 0x076f0e0d
            0xf129c6e2 = 0x7115607a
            0x9ccc70a1 = 0x7f5507c9
            0xdd9ec49e = 0xcf6696a6
            0x04788e64 = 0x053f291c
            0xf8b6848c = 0x4cdf29c2
            0x33638301 = 0x37843542
            0x7b9f8e23 = 0x4cdf29c2
            0x33d83abb = 0x2a3972c0
            0x8f88b97a = 0x4a36a0c6
            0x282e4631 = 0x17c8c673
            0x3dced93f = 0x4d311593
            0x3ecedad2 = 0xe6142a53
            0x3fcedc65 = 0xe51428c0
            0xf10bbaf1 = 0x00000000
            0xd03cfada = 0x00000000
            0x8b226ad3 = 0x92f120d7
            0x8c226c66 = 0xd559f79c
            0x8d226df9 = 0xd659f92f
            0x7752c1e0 = 0x10356e51
            0x7a52c699 = 0xb43b08df
            0x7952c506 = 0xb33b074c
            0x1efe93b9 = 0x9cf6e853
            0x6736ad73 = 0xa0ca9af1
            0x5809f1b1 = 0x9e7afa10
            0x90b7b10b = 0xa17afec9
            0xd19b7344 = 0x97987e8c
            0x4589841e = 0x146f4f16
            0xbab4b8ea = 0xbdaba8a0
            0xb46dc93d = 0xe2a44175
            0xb16dc484 = 0xdfa43cbc
            0xb26dc617 = 0xe0a43e4f
            0xdc1bb0e7 = 0xeb96bd98
            0x6e715827 = 0xeb985cbb
            0x6fdffc27 = 0x71760773
            0xae5bf0a8 = 0x12cf9fad
            0x2dcc93dc = 0x984a4512
            0x5326ed45 = 0xac0f790f
            0x257e0812 = 0x1773274b
            0x284e8a11 = 0x66b73d58
            0x254e8558 = 0x69b74211
            0x264e86eb = 0x68b7407e
            0x9f7cb2cb = 0xfcfa25c3
            0x0b4d0123 = 0xe9e4a93a
            0x7f4244fd = 0x309994f5
            0x67a6040c = 0x1f402804
            0xff0b5cd4 = 0x5e3c4b03
            0x369d615f = 0x150f2507
            0x2d3bbd40 = 0xd92657a8
            0x5dcdb9c2 = 0xc7263b52
            0x58a19010 = 0x67d57338
            0xb2c2cfe8 = 0x75ced237
            0xbce4cf06 = 0x58b4bed5
            0xecd6b378 = 0x199c7607
            0x5012532d = 0xa5ff6f15
            0xd18a5d69 = 0x49a22c31
            0xcb8a53f7 = 0x53a23bef
            0x55449d8d = 0xe5913635
            0x37446e53 = 0x7f9dc87c
            0x1375189b = 0xb6176833
            0x845d43da = 0x2235ffc2
            0x879327dd = 0x087e9c73
            0x9ffc9e5b = 0x7c040870
            0xd4854932 = 0x6c64df02
            0x3c7ed893 = 0x690ddcba
            0xb12bcae5 = 0x6482278c
            0x4e38fa17 = 0xe5a9ff9a
            0xc36cd4de = 0x6ed4cd0d
            0x2208ecae = 0x37e5a77d
            0xa3d96acd = 0x717b7448
            0x4b6e3eac = 0x048fdb4f
        }
    }
    0x773fb763 = StaticMaterialDef {
        Name: string = "Characters/Morgana/Skins/Skin80/Materials/Morgana_Skin80_Outline_Iridescent_Add_Scroll_Rework_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                TextureName: string = "MatCap_Tex"
                TexturePath: string = "ASSETS/Shared/Materials/black.SKINS_Sylas_Skin53.tex"
            }
            StaticMaterialShaderSamplerDef {
                TextureName: string = "Color_Mask_Texture"
                TexturePath: string = "ASSETS/Shared/Materials/white.tex"
            }
            StaticMaterialShaderSamplerDef {
                TextureName: string = "Diffuse_Texture"
                TexturePath: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Wings_TX_CM.SKINS_Morgana_Skin80.tex"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                TextureName: string = "iridescentTex"
                TexturePath: string = "ASSETS/Shared/Materials/Default_Gradient.tex"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                TextureName: string = "AdditiveScrollTex"
                TexturePath: string = "ASSETS/Shared/Materials/gray.tex"
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                TextureName: string = "AdditiveScroll_Mask"
                TexturePath: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Wing_Color_Mask_TX_CM.SKINS_Morgana_Skin80.tex"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                TextureName: string = "Diffuse_Texture2"
                TexturePath: string = "ASSETS/Shared/Materials/black.SKINS_Sylas_Skin53.tex"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Iridescence_Pulse_Speed_Min"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Diffuse_Fade_Mask_Value"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "SpecularControl"
                Value: vec4 = { 0, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "SpecularColor"
                Value: vec4 = { 1, 1, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Exclude_Mask_from_TintColor_Value"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "OutlineColor"
                Value: vec4 = { 1, 0.898207068, 0.600534081, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "OutlineThickness"
                Value: vec4 = { 0.102499999, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "OutlineSoftness"
                Value: vec4 = { 1.39999998, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveTexTile"
                Value: vec4 = { 1, 1, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "IridescentControl"
                Value: vec4 = { 0, 0.5, 0.5, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveStrength_R"
            }
            StaticMaterialShaderParamDef {
                Name: string = "TintColor"
                Value: vec4 = { 1, 1, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveScroll_ColorTint_R"
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveTexScrollSpeed_R"
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveTexScrollSpeed_G"
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveScroll_ColorTint_G"
                Value: vec4 = { 1, 0.537331223, 0, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveStrength_G"
                Value: vec4 = { 1.92499995, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Diffuse_Tex_BlendVlue"
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveTexScrollSpeed_A"
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveScroll_ColorTint_A"
            }
            StaticMaterialShaderParamDef {
                Name: string = "AdditiveStrength_A"
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Color"
                Value: vec4 = { 0, 1, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Bloom_Intensity"
                Value: vec4 = { 0.774999976, 0, 0, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "BLOOM_SCROLLTEX_ONLY"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "ADDITIVESCROLLTEX_R_SCREENSPACE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "ADDITIVESCROLLTEX_G_SCREENSPACE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "IRIDESCENCE_PULSE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "FADE_DIFFUSE_ONLY_W_MASK"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "FADE_DIFFUSE_ONLY"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "SCROLL_TEXTURE_ONLY"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "ADDITIVE_ALPHA"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "ALPHA_BLEND_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "SPECULAR_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "EXCLUDE_MASK_FROM_TINTCOLOR"
            }
            StaticMaterialSwitchDef {
                Name: string = "OUTLINE_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "IRIDESCENCE_OUTLINE"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "DIFFUSE_LERP_ON"
                On: bool = false
            }
            StaticMaterialSwitchDef {
                Name: string = "OUTLINE_MASK_ON"
            }
            StaticMaterialSwitchDef {
                Name: string = "INVERT_BLOOM_FRESNEL"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Outline_Iridescent_Add_Scroll"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "OutlineColor"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = SubmeshVisibilityBoolDriver {
                                    Submeshes: list[hash] = {
                                        0xf17b9bf8
                                    }
                                    Visible: bool = true
                                }
                                mValue: pointer = Float4LiteralMaterialDriver {
                                    Value: vec4 = { 1, 0.899999976, 0.600000024, 1 }
                                }
                            }
                        }
                        mDefaultValue: pointer = Float4LiteralMaterialDriver {
                            Value: vec4 = { 0, 1, 1, 1 }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "TintColor"
                    Enabled: bool = false
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = SubmeshVisibilityBoolDriver {
                                    Submeshes: list[hash] = {
                                        0xf17b9bf8
                                    }
                                    Visible: bool = true
                                }
                                mValue: pointer = Float4LiteralMaterialDriver {
                                    Value: vec4 = { 1, 0.370000005, 0, 1 }
                                }
                            }
                        }
                        mDefaultValue: pointer = Float4LiteralMaterialDriver {
                            Value: vec4 = { 0, 1, 1, 1 }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "AdditiveScroll_ColorTint_R"
                    Enabled: bool = false
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = SubmeshVisibilityBoolDriver {
                                    Submeshes: list[hash] = {
                                        0xf17b9bf8
                                    }
                                    Visible: bool = true
                                }
                                mValue: pointer = Float4LiteralMaterialDriver {
                                    Value: vec4 = { 1, 0.829999983, 0.200000003, 0 }
                                }
                            }
                        }
                        mDefaultValue: pointer = Float4LiteralMaterialDriver {
                            Value: vec4 = { 0.74000001, 1, 1, 0 }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "Bloom_Color"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = SubmeshVisibilityBoolDriver {
                                    Submeshes: list[hash] = {
                                        0xf17b9bf8
                                    }
                                    Visible: bool = true
                                }
                                mValue: pointer = Float4LiteralMaterialDriver {
                                    Value: vec4 = { 1, 0.579999983, 0, 1 }
                                }
                            }
                        }
                        mDefaultValue: pointer = Float4LiteralMaterialDriver {
                            Value: vec4 = { 0, 1, 1, 1 }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "AdditiveScroll_ColorTint_G"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = SubmeshVisibilityBoolDriver {
                                    Submeshes: list[hash] = {
                                        0xf17b9bf8
                                    }
                                    Visible: bool = true
                                }
                                mValue: pointer = Float4LiteralMaterialDriver {
                                    Value: vec4 = { 1, 0.540000021, 0, 0 }
                                }
                            }
                        }
                        mDefaultValue: pointer = Float4LiteralMaterialDriver {
                            Value: vec4 = { 0, 0.519999981, 1, 0 }
                        }
                    }
                }
            }
            Textures: list[embed] = {
                DynamicMaterialTextureSwapDef {
                    Name: string = "Diffuse_Texture"
                    Options: list[embed] = {
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xf17b9bf8
                                }
                                Visible: bool = true
                            }
                            TextureName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_WingsEvolve_TX_CM.SKINS_Morgana_Skin80.tex"
                        }
                    }
                }
            }
        }
    }
    0xa9f40391 = StaticMaterialDef {
        Name: string = "Characters/Morgana/Skins/Skin80/Materials/Morgana_Skin80_Body_inst"
        SamplerValues: list2[embed] = {
            StaticMaterialShaderSamplerDef {
                TextureName: string = "Diffuse_Color"
                TexturePath: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_TX_CM.SKINS_Morgana_Skin80.tex"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                TextureName: string = "Mask"
                TexturePath: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Mask_TX_CM.SKINS_Morgana_Skin80.tex"
                AddressU: u32 = 1
                AddressV: u32 = 1
                AddressW: u32 = 1
            }
            StaticMaterialShaderSamplerDef {
                TextureName: string = "iridescentTex"
                TexturePath: string = "ASSETS/Shared/Materials/Default_Gradient.tex"
            }
        }
        ParamValues: list2[embed] = {
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Color"
                Value: vec4 = { 0.396078438, 0.41568628, 1, 1 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Fresnel_Size"
                Value: vec4 = { 0.485000014, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "Shadow_Bias"
                Value: vec4 = { 1, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "MaxSpec"
                Value: vec4 = { 17.1200008, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "LQ_Lighting_Intensity"
                Value: vec4 = { 1.75, 0, 0, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "RimLightOffset"
            }
            StaticMaterialShaderParamDef {
                Name: string = "SpecularColor"
                Value: vec4 = { 0, 0.996612489, 0.291004807, 0 }
            }
            StaticMaterialShaderParamDef {
                Name: string = "IridescentControl"
                Value: vec4 = { 1, 0.5, 0.5, 0 }
            }
        }
        Switches: list2[embed] = {
            StaticMaterialSwitchDef {
                Name: string = "IRIDESCENCE_ON"
                On: bool = false
            }
        }
        ShaderMacros: map[string,string] = {
            "NUM_BLEND_WEIGHTS" = "4"
        }
        Techniques: list[embed] = {
            StaticMaterialTechniqueDef {
                Name: string = "normal"
                Passes: list[embed] = {
                    StaticMaterialPassDef {
                        Shader: link = "Shaders/SkinnedMesh/Specular_Fresnel_Masked"
                        BlendEnable: bool = true
                        SrcColorBlendFactor: u32 = 6
                        SrcAlphaBlendFactor: u32 = 6
                        DstColorBlendFactor: u32 = 7
                        DstAlphaBlendFactor: u32 = 7
                    }
                }
            }
        }
        ChildTechniques: list[embed] = {
            StaticMaterialChildTechniqueDef {
                Name: string = "transition"
                ParentName: string = "normal"
                ShaderMacros: map[string,string] = {
                    "TRANSITION" = "1"
                }
            }
        }
        DynamicMaterial: pointer = DynamicMaterialDef {
            Parameters: list[embed] = {
                DynamicMaterialParameterDef {
                    Name: string = "Fresnel_Color"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = OneTrueMaterialDriver {
                                    mDrivers: list[pointer] = {
                                        HasBuffDynamicMaterialBoolDriver {
                                            Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                                        }
                                    }
                                }
                                mValue: pointer = Float4LiteralMaterialDriver {
                                    Value: vec4 = { 0.25, 0.0799999982, 0.469999999, 1 }
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = SubmeshVisibilityBoolDriver {
                                    Submeshes: list[hash] = {
                                        0xf17b9bf8
                                    }
                                    Visible: bool = true
                                }
                                mValue: pointer = Float4LiteralMaterialDriver {
                                    Value: vec4 = { 0.400000006, 0.419999987, 1, 1 }
                                }
                            }
                        }
                        mDefaultValue: pointer = Float4LiteralMaterialDriver {
                            Value: vec4 = { 0.790000021, 0.800000012, 1, 1 }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "SpecularColor"
                    Driver: pointer = SwitchMaterialDriver {
                        mElements: list[embed] = {
                            SwitchMaterialDriverElement {
                                mCondition: pointer = OneTrueMaterialDriver {
                                    mDrivers: list[pointer] = {
                                        HasBuffDynamicMaterialBoolDriver {
                                            Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                                        }
                                    }
                                }
                                mValue: pointer = Float4LiteralMaterialDriver {
                                    Value: vec4 = { 0, 1, 0.289999992, 0 }
                                }
                            }
                            SwitchMaterialDriverElement {
                                mCondition: pointer = SubmeshVisibilityBoolDriver {
                                    Submeshes: list[hash] = {
                                        0xf17b9bf8
                                    }
                                    Visible: bool = true
                                }
                                mValue: pointer = Float4LiteralMaterialDriver {
                                    Value: vec4 = { 0, 1, 0.289999992, 0 }
                                }
                            }
                        }
                        mDefaultValue: pointer = Float4LiteralMaterialDriver {
                            Value: vec4 = { 0.129999995, 0.330000013, 0.319999993, 0 }
                        }
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "LQ_Lighting_Intensity"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = OneTrueMaterialDriver {
                            mDrivers: list[pointer] = {
                                HasBuffDynamicMaterialBoolDriver {
                                    Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                                }
                            }
                        }
                        mOnValue: f32 = 19
                        mOffValue: f32 = 1.75
                        mTurnOnTimeSec: f32 = 0.200000003
                        mTurnOffTimeSec: f32 = 0.200000003
                    }
                }
                DynamicMaterialParameterDef {
                    Name: string = "MaxSpec"
                    Driver: pointer = LerpMaterialDriver {
                        mBoolDriver: pointer = OneTrueMaterialDriver {
                            mDrivers: list[pointer] = {
                                HasBuffDynamicMaterialBoolDriver {
                                    Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                                }
                            }
                        }
                        mOnValue: f32 = 5.69999981
                        mOffValue: f32 = 17.1200008
                        mTurnOnTimeSec: f32 = 0.200000003
                        mTurnOffTimeSec: f32 = 0.200000003
                    }
                }
            }
            Textures: list[embed] = {
                DynamicMaterialTextureSwapDef {
                    Name: string = "Diffuse_Color"
                    Options: list[embed] = {
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = OneTrueMaterialDriver {
                                mDrivers: list[pointer] = {
                                    HasBuffDynamicMaterialBoolDriver {
                                        Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                                    }
                                    IsCastingBoolDriver {
                                        SpellSlot: u32 = 3
                                    }
                                }
                            }
                            TextureName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Ult_TX_CM.SKINS_Morgana_Skin80.tex"
                        }
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = OneTrueMaterialDriver {
                                mDrivers: list[pointer] = {
                                    HasBuffDynamicMaterialBoolDriver {
                                        Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                                    }
                                }
                            }
                            TextureName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Ult_TX_CM.SKINS_Morgana_Skin80.tex"
                        }
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xf17b9bf8
                                }
                                Visible: bool = true
                            }
                            TextureName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Evolve_TX_CM.SKINS_Morgana_Skin80.tex"
                        }
                    }
                }
                DynamicMaterialTextureSwapDef {
                    Name: string = "Mask"
                    Options: list[embed] = {
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = HasBuffDynamicMaterialBoolDriver {
                                Spell: hash = "Characters/Morgana/Spells/MorganaRAbility/MorganaR"
                            }
                            TextureName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Mask_TX_CM.SKINS_Morgana_Skin80.tex"
                        }
                        DynamicMaterialTextureSwapOption {
                            Driver: pointer = SubmeshVisibilityBoolDriver {
                                Submeshes: list[hash] = {
                                    0xf17b9bf8
                                }
                                Visible: bool = true
                            }
                            TextureName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Evolve_Mask_TX_CM.SKINS_Morgana_Skin80.tex"
                        }
                    }
                }
            }
        }
    }
    0x127f0462 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            3
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    0.800000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.600000024
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    3
                }
                EmitterName: string = "Wing Petals"
                Importance: u8 = 2
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.100000001
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -25, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -25, 0 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -25, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -25, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[f32] = {
                            0
                            0
                        }
                    }
                }
                SpawnShape: pointer = VfxShapeSphere {
                    Flags: u8 = 1
                    Radius: f32 = 20
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Petal_Mesh.SKINS_Morgana_Skin80.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.843137264, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.25
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.25
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    0.790000021
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.25
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0, 0.843137264, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 2, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -0.800000012
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 3, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 3, 1, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 8, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 8, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 1, 1 }
                            { 0.800000012, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_FlowerPetalz.SKINS_Morgana_Skin80.tex"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 4
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            1
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    5
                }
                EmitterName: string = "Motes"
                BirthDrag: embed = ValueVector3 {
                    ConstantValue: vec3 = { 2, 2, 2 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 2, 2, 2 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, 10, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 10, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 0.5
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[f32] = {
                            0.25
                            0
                        }
                    }
                }
                SpawnShape: pointer = VfxShapeSphere {
                    Radius: f32 = 50
                }
                BlendMode: u8 = 4
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.330000013
                            0.660000026
                            1
                        }
                        Values: list[vec4] = {
                            { 0.0563668273, 0.00784313772, 0.294117659, 0 }
                            { 0.131364927, 0.689555228, 0.974547923, 1 }
                            { 0.113527127, 0.0274509806, 1, 1 }
                            { 0.0509803928, 0, 0.101960786, 0 }
                        }
                    }
                }
                Pass: i16 = 30
                IsUniformScale: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 360, 360, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 360, 360, 0 }
                        }
                    }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -0.800000012
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                BirthRotationalAcceleration: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 3, 0, 0 }
                        }
                    }
                }
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1, 0, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1, 0, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 20, 50, 50 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 20, 50, 50 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.129999995
                            0.200000003
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 0.5, 1.5, 1 }
                            { 1, 1, 1 }
                            { 0, 0, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Q_Stardust.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 2
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    1
                                    0.5
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            2
                        }
                    }
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 0.600000024
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    0.800000012
                                    1
                                }
                            }
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[f32] = {
                            0.600000024
                        }
                    }
                }
                ParticleLinger: option[f32] = {
                    3
                }
                EmitterName: string = "Wing Petals1"
                Importance: u8 = 2
                BirthOrbitalVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.100000001
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                BirthVelocity: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -25, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.699999988
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -25, 0 }
                        }
                    }
                }
                WorldAcceleration: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 0, -25, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, -25, 0 }
                        }
                    }
                }
                BindWeight: embed = ValueFloat {
                    Dynamics: pointer = VfxAnimatedFloatVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                        }
                        Values: list[f32] = {
                            0
                            0
                        }
                    }
                }
                SpawnShape: pointer = VfxShapeSphere {
                    Flags: u8 = 1
                    Radius: f32 = 20
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mSimpleMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Petal_Mesh.SKINS_Morgana_Skin80.scb"
                    }
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.592675686, 0.403921574, 1, 1 }
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.25
                                }
                                KeyValues: list[f32] = {
                                    0.5
                                    1
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.25
                                }
                                KeyValues: list[f32] = {
                                    0.75
                                    0.790000021
                                }
                            }
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.25
                                }
                                KeyValues: list[f32] = {
                                    1
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec4] = {
                            { 0.592675686, 0.403921574, 1, 1 }
                        }
                    }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.200000003
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                DisableBackfaceCull: bool = true
                IsUniformScale: flag = true
                IsRandomStartFrame: flag = true
                IsRotationEnabled: flag = true
                UseNavmeshMask: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 90, 2, 0 }
                }
                BirthRotationalVelocity0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 1, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    0.5
                                    0.500999987
                                    1
                                }
                                KeyValues: list[f32] = {
                                    -1
                                    -0.800000012
                                    0.800000012
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 0, 1, 0 }
                        }
                    }
                }
                IsLocalOrientation: flag = false
                Rotation0: embed = IntegratedValueVector3 {
                    ConstantValue: vec3 = { 1.5, 0.5, 0 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 1.5, 0.5, 0 }
                        }
                    }
                }
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 10, 30, 30 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        ProbabilityTables: list[pointer] = {
                            VfxProbabilityTableData {
                                KeyTimes: list[f32] = {
                                    0
                                    1
                                }
                                KeyValues: list[f32] = {
                                    0.400000006
                                    1
                                }
                            }
                            VfxProbabilityTableData {}
                            VfxProbabilityTableData {}
                        }
                        Times: list[f32] = {
                            0
                        }
                        Values: list[vec3] = {
                            { 10, 30, 30 }
                        }
                    }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0.800000012, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            1
                        }
                        Values: list[vec3] = {
                            { 0.800000012, 1, 1 }
                            { 0.800000012, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_FlowerPetalz.SKINS_Morgana_Skin80.tex"
                NumFrames: u16 = 4
                TexDiv: vec2 = { 2, 2 }
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 3
                }
                ParticleLifetime: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    0.5
                }
                EmitterName: string = "Glow"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                FlexShapeDefinition: pointer = VfxFlexShapeDefinitionData {
                    ScaleBirthScaleByBoundObjectSize: f32 = 0.00200000009
                    ScaleEmitOffsetByBoundObjectSize: f32 = 0.0199999996
                }
                BlendMode: u8 = 4
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.190005347, 0.550000012, 0.820004582, 0.200000003 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 0 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 0 }
                        }
                    }
                }
                AlphaRef: u8 = 0
                UseNavmeshMask: flag = true
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 300, 200, 0 }
                }
                Scale0: embed = ValueVector3 {
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            1
                        }
                        Values: list[vec3] = {
                            { 1, 1, 1 }
                            { 1, 1, 1 }
                            { 1.20000005, 1.20000005, 1.20000005 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Glow.SKINS_Morgana_Skin80.tex"
            }
        }
        ParticleName: string = "Morgana_Skin80_Idle_WingGlowL"
        ParticlePath: string = "Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Idle_WingGlowL"
        Flags: u16 = 1239
    }
    0xe83e4e99 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = 0x3e939e5f
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0x5493c101
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0xbcc202c8
                        }
                    }
                    BoneToSpawnAt: list[string] = {
                        "Buffbone_Cstm_Mask1_L_Eye"
                        "Buffbone_Cstm_Mask1_R_Eye"
                        "Mask1_Jaw"
                    }
                    ParentInheritanceDefinition: pointer = VfxParentInheritanceParams {
                        Mode: u8 = 12
                    }
                }
                EmitterName: string = "Mask_Main"
                Linger: pointer = VfxLingerDefinitionData {}
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -45, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 3
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.92310977, 0.947600543, 0.960784316, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 205
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.0199999996
                    FresnelColor: vec4 = { 0, 0.397650123, 0.724086344, 0 }
                }
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.600000024, 0, 0 }
                            { 1.44000006, 1.10000002, 1.10000002 }
                            { 1.20000005, 1, 1 }
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Edge"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.607171714, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 203
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.29999995, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.649999976, 0, 0 }
                            { 1.56000006, 1.10000002, 1.10000002 }
                            { 1.29999995, 1, 1 }
                            { 1.29999995, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                TimeBeforeFirstEmission: f32 = 0.100000001
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Fire"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -60, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.829999208, 1, 0.659998477 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 204
                AlphaRef: u8 = 50
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0.75, 0, 0 }
                            { 1.80000007, 1.10000002, 1.10000002 }
                            { 1.5, 1, 1 }
                            { 1.5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 90
                }
                TextureMult: pointer = VfxTextureMultDefinitionData {
                    TextureMult: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Jayce_Skin35_PlasmaNoise.SKINS_Morgana_Skin80.tex"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 4, 2 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { -0.5, 1 }
                    }
                }
            }
        }
        ParticleName: string = "Morgana_Skin80_R_Mask01"
        ParticlePath: string = "Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_R_Mask01"
        Flags: u16 = 197
        Transform: mtx44 = {
            0.99999994, 0, 0, 0
            0, 0.99999994, 0, 0
            0, 0, 0.999999881, 0
            0, 500, 0, 1
        }
    }
    0xe53e49e0 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = 0x3e939e5f
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0x5493c101
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0xbcc202c8
                        }
                    }
                    BoneToSpawnAt: list[string] = {
                        "Buffbone_Cstm_Mask2_L_Eye"
                        "Buffbone_Cstm_Mask2_R_Eye"
                        "Mask2_Jaw"
                    }
                    ParentInheritanceDefinition: pointer = VfxParentInheritanceParams {
                        Mode: u8 = 12
                    }
                }
                EmitterName: string = "Mask_Main"
                Linger: pointer = VfxLingerDefinitionData {}
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -45, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 3
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.92310977, 0.947600543, 0.960784316, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 205
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.0199999996
                    FresnelColor: vec4 = { 0, 0.397650123, 0.724086344, 0 }
                }
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.600000024, 0, 0 }
                            { 1.44000006, 1.10000002, 1.10000002 }
                            { 1.20000005, 1, 1 }
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Edge"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.607171714, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 203
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.29999995, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.649999976, 0, 0 }
                            { 1.56000006, 1.10000002, 1.10000002 }
                            { 1.29999995, 1, 1 }
                            { 1.29999995, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Fire"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -60, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.829999208, 1, 0.659998477 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 204
                AlphaRef: u8 = 50
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0.75, 0, 0 }
                            { 1.80000007, 1.10000002, 1.10000002 }
                            { 1.5, 1, 1 }
                            { 1.5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 90
                }
                TextureMult: pointer = VfxTextureMultDefinitionData {
                    TextureMult: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Jayce_Skin35_PlasmaNoise.SKINS_Morgana_Skin80.tex"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 4, 2 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { -0.5, 1 }
                    }
                }
            }
        }
        ParticleName: string = "Morgana_Skin80_R_Mask02"
        ParticlePath: string = "Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_R_Mask02"
        Flags: u16 = 197
        Transform: mtx44 = {
            0.99999994, 0, 0, 0
            0, 0.99999994, 0, 0
            0, 0, 0.999999881, 0
            0, 500, 0, 1
        }
    }
    0xa3f51e36 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = 0x3e939e5f
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0x5493c101
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0xbcc202c8
                        }
                    }
                    BoneToSpawnAt: list[string] = {
                        "Buffbone_Cstm_Mask3_L_Eye"
                        "Buffbone_Cstm_Mask3_R_Eye"
                        "Mask3_Jaw"
                    }
                    ParentInheritanceDefinition: pointer = VfxParentInheritanceParams {
                        Mode: u8 = 12
                    }
                }
                EmitterName: string = "Mask_Main"
                Linger: pointer = VfxLingerDefinitionData {}
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -45, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 3
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 205
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.0199999996
                    FresnelColor: vec4 = { 0, 0.397650123, 0.724086344, 0 }
                }
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.600000024, 0, 0 }
                            { 1.44000006, 1.10000002, 1.10000002 }
                            { 1.20000005, 1, 1 }
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Edge"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0, 0.607171714, 1, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 203
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.29999995, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.649999976, 0, 0 }
                            { 1.56000006, 1.10000002, 1.10000002 }
                            { 1.29999995, 1, 1 }
                            { 1.29999995, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Fire"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -60, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.200000003, 0.829999208, 1, 0.659998477 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 204
                AlphaRef: u8 = 50
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0.75, 0, 0 }
                            { 1.80000007, 1.10000002, 1.10000002 }
                            { 1.5, 1, 1 }
                            { 1.5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 90
                }
                TextureMult: pointer = VfxTextureMultDefinitionData {
                    TextureMult: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Jayce_Skin35_PlasmaNoise.SKINS_Morgana_Skin80.tex"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 4, 2 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { -0.5, 1 }
                    }
                }
            }
        }
        ParticleName: string = "Morgana_Skin80_R_Mask_03"
        ParticlePath: string = "Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_R_Mask_03"
        Flags: u16 = 197
        Transform: mtx44 = {
            0.99999994, 0, 0, 0
            0, 0.99999994, 0, 0
            0, 0, 0.999999881, 0
            0, 500, 0, 1
        }
    }
    0xa6f522ef = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = 0x3e939e5f
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0x5493c101
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0x6f251162
                        }
                    }
                    BoneToSpawnAt: list[string] = {
                        "Buffbone_Cstm_Mask1_L_Eye"
                        "Buffbone_Cstm_Mask1_R_Eye"
                        "Mask1_Jaw"
                    }
                    ParentInheritanceDefinition: pointer = VfxParentInheritanceParams {
                        Mode: u8 = 12
                    }
                }
                EmitterName: string = "Mask_Main"
                Linger: pointer = VfxLingerDefinitionData {}
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -45, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 3
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.92310977, 0.947600543, 0.960784316, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 205
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.0199999996
                    FresnelColor: vec4 = { 0, 0.397650123, 0.724086344, 0 }
                }
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.600000024, 0, 0 }
                            { 1.44000006, 1.10000002, 1.10000002 }
                            { 1.20000005, 1, 1 }
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Edge"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.868833423, 0.412054628, 0.203952089, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 203
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.29999995, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.649999976, 0, 0 }
                            { 1.56000006, 1.10000002, 1.10000002 }
                            { 1.29999995, 1, 1 }
                            { 1.29999995, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Fire"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -60, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_1_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.566140234, 0.200000003, 0.65882355 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 204
                AlphaRef: u8 = 50
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0.75, 0, 0 }
                            { 1.80000007, 1.10000002, 1.10000002 }
                            { 1.5, 1, 1 }
                            { 1.5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 90
                }
                TextureMult: pointer = VfxTextureMultDefinitionData {
                    TextureMult: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Jayce_Skin35_PlasmaNoise.SKINS_Morgana_Skin80.tex"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 4, 2 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { -0.5, 1 }
                    }
                }
            }
        }
        ParticleName: string = "Morgana_Skin80_R_Mask_04"
        ParticlePath: string = "Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_R_Mask_04"
        Flags: u16 = 197
        Transform: mtx44 = {
            0.99999994, 0, 0, 0
            0, 0.99999994, 0, 0
            0, 0, 0.999999881, 0
            0, 500, 0, 1
        }
    }
    0xa5f5215c = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = 0x3e939e5f
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0x5493c101
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0x6f251162
                        }
                    }
                    BoneToSpawnAt: list[string] = {
                        "Buffbone_Cstm_Mask2_L_Eye"
                        "Buffbone_Cstm_Mask2_R_Eye"
                        "Mask2_Jaw"
                    }
                    ParentInheritanceDefinition: pointer = VfxParentInheritanceParams {
                        Mode: u8 = 12
                    }
                }
                EmitterName: string = "Mask_Main"
                Linger: pointer = VfxLingerDefinitionData {}
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -45, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 3
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.92310977, 0.947600543, 0.960784316, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 205
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.0199999996
                    FresnelColor: vec4 = { 0, 0.397650123, 0.724086344, 0 }
                }
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.600000024, 0, 0 }
                            { 1.44000006, 1.10000002, 1.10000002 }
                            { 1.20000005, 1, 1 }
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Edge"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.868833423, 0.412054628, 0.203952089, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 203
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.29999995, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.649999976, 0, 0 }
                            { 1.56000006, 1.10000002, 1.10000002 }
                            { 1.29999995, 1, 1 }
                            { 1.29999995, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Fire"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -60, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_2_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.566140234, 0.200000003, 0.65882355 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 204
                AlphaRef: u8 = 50
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0.75, 0, 0 }
                            { 1.80000007, 1.10000002, 1.10000002 }
                            { 1.5, 1, 1 }
                            { 1.5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 90
                }
                TextureMult: pointer = VfxTextureMultDefinitionData {
                    TextureMult: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Jayce_Skin35_PlasmaNoise.SKINS_Morgana_Skin80.tex"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 4, 2 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { -0.5, 1 }
                    }
                }
            }
        }
        ParticleName: string = "Morgana_Skin80_R_Mask_05"
        ParticlePath: string = "Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_R_Mask_05"
        Flags: u16 = 197
        Transform: mtx44 = {
            0.99999994, 0, 0, 0
            0, 0.99999994, 0, 0
            0, 0, 0.999999881, 0
            0, 500, 0, 1
        }
    }
    0xa8f52615 = VfxSystemDefinitionData {
        ComplexEmitterDefinitionData: list[pointer] = {
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                IsSingleParticle: flag = true
                ChildParticleSetDefinition: pointer = VfxChildParticleSetDefinitionData {
                    ChildrenIdentifiers: list[embed] = {
                        VfxChildIdentifier {
                            EffectKey: hash = 0x3e939e5f
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0x5493c101
                        }
                        VfxChildIdentifier {
                            EffectKey: hash = 0x6f251162
                        }
                    }
                    BoneToSpawnAt: list[string] = {
                        "Buffbone_Cstm_Mask3_L_Eye"
                        "Buffbone_Cstm_Mask3_R_Eye"
                        "Mask3_Jaw"
                    }
                    ParentInheritanceDefinition: pointer = VfxParentInheritanceParams {
                        Mode: u8 = 12
                    }
                }
                EmitterName: string = "Mask_Main"
                Linger: pointer = VfxLingerDefinitionData {}
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -45, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 3
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.92310977, 0.947600543, 0.960784316, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.100000001
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 205
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.0199999996
                    FresnelColor: vec4 = { 0, 0.397650123, 0.724086344, 0 }
                }
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.20000005, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.600000024, 0, 0 }
                            { 1.44000006, 1.10000002, 1.10000002 }
                            { 1.20000005, 1, 1 }
                            { 1.20000005, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Morgana_Skin80_Masks_TX_CM.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Edge"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -50, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 0.868833423, 0.412054628, 0.203952089, 1 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 203
                AlphaRef: u8 = 0
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.29999995, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0199999996
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0, 1, 1 }
                            { 0.649999976, 0, 0 }
                            { 1.56000006, 1.10000002, 1.10000002 }
                            { 1.29999995, 1, 1 }
                            { 1.29999995, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
            }
            VfxEmitterDefinitionData {
                Rate: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                ParticleLinger: option[f32] = {
                    1
                }
                IsSingleParticle: flag = true
                EmitterName: string = "Mask_Fire"
                BindWeight: embed = ValueFloat {
                    ConstantValue: f32 = 1
                }
                SpawnShape: pointer = 0xee39916f {}
                EmitterPosition: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, -60, 0 }
                }
                Primitive: pointer = VfxPrimitiveMesh {
                    mMesh: embed = VfxMeshDefinitionData {
                        mMeshName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skn"
                        mMeshSkeletonName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.skl"
                        mAnimationName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_Masks_Ult_3_RCast.SKINS_Morgana_Skin80.anm"
                    }
                }
                BlendMode: u8 = 1
                BirthColor: embed = ValueColor {
                    ConstantValue: vec4 = { 1, 0.566140234, 0.200000003, 0.65882355 }
                }
                Color: embed = ValueColor {
                    Dynamics: pointer = VfxAnimatedColorVariableData {
                        Times: list[f32] = {
                            0
                            0.5
                            0.75
                            1
                        }
                        Values: list[vec4] = {
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                            { 1, 1, 1, 1 }
                        }
                    }
                }
                Pass: i16 = 204
                AlphaRef: u8 = 50
                AlphaErosionDefinition: pointer = VfxAlphaErosionDefinitionData {
                    ErosionDriveCurve: embed = ValueFloat {
                        ConstantValue: f32 = 0
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                0.5
                                0.800000012
                            }
                            Values: list[f32] = {
                                0
                                0
                                0
                            }
                        }
                    }
                    UseLingerErosionDriveCurve: bool = true
                    LingerErosionDriveCurve: embed = ValueFloat {
                        Dynamics: pointer = VfxAnimatedFloatVariableData {
                            Times: list[f32] = {
                                0
                                1
                            }
                            Values: list[f32] = {
                                0
                                1
                            }
                        }
                    }
                    ErosionFeatherIn: f32 = 0.0299999993
                    ErosionFeatherOut: f32 = 0.0299999993
                    ErosionMapName: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Morgana_Base_E_SmokeErode.SKINS_Morgana_Skin80.tex"
                    ErosionMapChannelMixer: embed = ValueColor {
                        ConstantValue: vec4 = { 1, 0, 0, 0 }
                    }
                }
                ReflectionDefinition: pointer = VfxReflectionDefinitionData {
                    Fresnel: f32 = 0.100000001
                    FresnelColor: vec4 = { 0.475043863, 0.690608084, 0.747508943, 0 }
                }
                0xcb13aff1: f32 = 50
                IsUniformScale: flag = true
                IsRotationEnabled: flag = true
                BirthRotation0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 0, 180, 0 }
                }
                IsLocalOrientation: flag = false
                BirthScale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 3, 3.5, 3.5 }
                }
                Scale0: embed = ValueVector3 {
                    ConstantValue: vec3 = { 1.5, 1, 1 }
                    Dynamics: pointer = VfxAnimatedVector3fVariableData {
                        Times: list[f32] = {
                            0
                            0.0500000007
                            0.0799999982
                            1
                        }
                        Values: list[vec3] = {
                            { 0.75, 0, 0 }
                            { 1.80000007, 1.10000002, 1.10000002 }
                            { 1.5, 1, 1 }
                            { 1.5, 1, 1 }
                        }
                    }
                }
                Texture: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Base_white_RGB.SKINS_Morgana_Skin80.tex"
                UvRotation: embed = ValueFloat {
                    ConstantValue: f32 = 90
                }
                TextureMult: pointer = VfxTextureMultDefinitionData {
                    TextureMult: string = "ASSETS/Characters/Morgana/Skins/Skin80/Particles/Jayce_Skin35_PlasmaNoise.SKINS_Morgana_Skin80.tex"
                    UvScaleMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { 4, 2 }
                    }
                    BirthUvScrollRateMult: embed = ValueVector2 {
                        ConstantValue: vec2 = { -0.5, 1 }
                    }
                }
            }
        }
        ParticleName: string = "Morgana_Skin80_R_Mask_06"
        ParticlePath: string = "Characters/Morgana/Skins/Skin80/Particles/Morgana_Skin80_R_Mask_06"
        Flags: u16 = 197
        Transform: mtx44 = {
            0.99999994, 0, 0, 0
            0, 0.99999994, 0, 0
            0, 0, 0.999999881, 0
            0, 500, 0, 1
        }
    }
}
